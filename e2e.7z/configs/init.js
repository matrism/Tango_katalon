"use strict";
ftf.controller.process();
