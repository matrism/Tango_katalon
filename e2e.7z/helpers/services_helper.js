if (typeof ftf === "undefined") {
    throw new Error ("Framework is not loaded");
}

if (typeof ftf.helper === "undefined") {
    ftf.helper = {};
}

if (typeof ftf.helper.service === "undefined") {
    ftf.helper.service = {};
}









