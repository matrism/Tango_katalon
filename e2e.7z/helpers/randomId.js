"use strict";
module.exports = function() {
	return Date.now().toString() + Math.floor(Math.random() * 1000);
};
