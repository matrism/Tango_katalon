"use strict";
var promise = protractor.promise;
var ExpectedConditions = protractor.ExpectedConditions;
if (pages.royaltyRates === undefined) {
    pages.royaltyRates = new ftf.pageObject({
        url: _tf_config.urls.app_url + "#/create/deal",
        locators: {

            newRoyaltyRateSetButton: {xpath:".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[5]/a"},
            contractualRateField: {xpath:".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[3]/div[2]/div/input"},
            rrNpsRate: {xpath:".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[3]/div[2]/div/div/ul[1]/li[2]"},

            //dealSigningTerritory: {css: "button.openPopupButton"},
            //dealSigningTerritoryDropDownData: {css: "div.typeaheadDropdown"},
            //contractingPartiesInput: {xpath: "//*[@ng-model='contractingParties']//div[@ng-class='tgTypeaheadWrapClass']//input[@ng-disabled='$isDisabled()']"},
            //contractingPartiesField: {xpath: "//*[@ng-model='contractingParties']//div[@ng-class='tgTypeaheadWrapClass']"},
            //contractingPartiesDropDownData: {xpath: "//*[@class='ng-scope']//ul[@class='tg-typeahead__suggestions ng-scope']//li[@class='tg-typeahead__suggestions-group-item ng-scope']/div"},
            //continueButton: {xpath: "//*[@class='page-footer']//button[contains(text(),'Continue')]"},
            //start_date: {xpath: "//*[@id='actualStartDate']//input"},
            //end_target_months: {xpath: "//*[@name='targetEndDuration']"},
            //add_scope_icon: {xpath: "//*[@class='overview-header']//h3[contains(text(),'Scopes')]//a[@class='column-add-button']"},
            //contract_type_dropdown: {name: "scopeContractType"},
            //territory_field: {xpath: "//*[@class='territoriesStaticView']"},
            //territory_input: {xpath: "//fieldset[2]/div/div/div/div[2]/div[3]/div[1]/input"}

            closeRateSetButton: {xpath: ".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[1]/div/button"},

            confirmCancelButton: {xpath:"//html/body/div[10]/div/div[3]/button[2]"},

            royaltyRateName: {xpath:".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[2]/div[1]/input"},
            RRNameLabel: {xpath: ".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[2]/div[1]/div[1]/label"},
            incomeProvidesLabel: {xpath :".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[2]/div[2]/label"},
            incomeProviderInput: {xpath: ".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[2]/div[2]/div[1]/div/div[1]/ul"},
            incomeDateMethodLabel: {xpath: ".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[2]/div[3]/label"},
            dealSigningLabel: {xpath: ".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[2]/div[3]/div/button[1]"},
            warnerChappelLabel:{xpath: ".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[2]/div[3]/div/button[2]"},
            effectiveStartDateLabel: {xpath: ".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[2]/div[4]/label"},
            effectiveStartDateInput: {xpath : ".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[2]/div[4]/div[1]/input"},
            contractualRateLabel: {xpath: ".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[3]/div[2]/label"},
            contractualRateInput: {xpath : ".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[3]/div[2]/div/input"},
            interCompanyLabel: {xpath: ".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[3]/div[3]/label"},
            interCompanyInput: {xpath : ".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[3]/div[3]/div/input"},





        },



      clickNewRoyaltySetButton: function()
      {

        //  ftf.helper.waitForElement(  pages.royaltyRates.elems.newRoyaltyRateSetButton,30000);


              browser.wait(ExpectedConditions.visibilityOf(pages.royaltyRates.elems.newRoyaltyRateSetButton),30000);
          pages.royaltyRates.elems.newRoyaltyRateSetButton.click();
      }
        ,
        expandAllIncomeGroups: function() {
            var i = 0 ;
            browser.driver.findElements(by.xpath(".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[3]/div/div[1]/a/i"))

                .then(function(result)
                {

                    for (i = 0; i < result.length; i++) {
                        result[i].click();
                    }
                }
            )


        },

        closeRoyaltySet:function(){
          pages.royaltyRates.elems.closeRateSetButton.click();

            ftf.helper.waitForElement(pages.royaltyRates.elems.confirmCancelButton,30000);
          //  if(pages.royaltyRates.elems.confirmCancelButton.isPresent())
           pages.royaltyRates.elems.confirmCancelButton.click();

        },

        fillContractualRate: function(value)
        {
            ftf.pageObject.prototype.scrollIntoView(  pages.royaltyRates.elems.contractualRateField);
            pages.royaltyRates.elems.contractualRateField.click();
            pages.royaltyRates.elems.contractualRateField.sendKeys(value);
            pages.royaltyRates.elems.rrNpsRate.click();

        },

        clearNameInput: function()
        {
            var royaltyRateInput;

            royaltyRateInput = browser.driver.findElement(by.xpath(".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[2]/div[1]/input"));
          //  pages.base.scrollIntoView(royaltyRateInput);

            //ftf.pageObject.prototype.scrollIntoView(royaltyRateInput);
            royaltyRateInput.clear();


        },

        selectIncomeProvider: function()
        {

            var suggestion = $(".ng-scope.ng-binding>strong");
            browser.wait(ExpectedConditions.visibilityOf(suggestion));
            expect(suggestion.getText()).not.toContain("No results");


            var desiredOption;
            browser.driver.findElements(by.css('.ng-scope.ng-binding>strong'))
                .then(function findMatchingOption(options) {
                    options.some(function (option) {
                        option.getText().then(function doesOptionMatch(text) {
                                if (text.indexOf("TEST") != -1) {
                                    desiredOption = option;
                                    return true;
                                }
                            }
                        )
                    });
                })
                .then(function clickOption() {
                    if (desiredOption) {
                        desiredOption.click();
                    }
                });


        },

        returnExpectValue: function()
        {


                return   royaltyRateInput.getCssValue('border-top-color');
        };






    });
}

module.exports = pages.new_deal;