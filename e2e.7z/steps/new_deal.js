var _ = require("lodash");
var promise = protractor.promise;
var ExpectedConditions = protractor.ExpectedConditions;
if (steps.new_deal === undefined) {
    steps.new_deal = {
        itCreateBasicDeal: function () {
            describe("Create basic deal", function () {

                it("Open create deal page", function () {
                    pages.new_deal.open().waitForAjax();

                });

                it("Select desired deal signing territory", function () {
                    pages.new_deal.selectDesiredSigningTerritory();
                });

                it("Fill in contracting parties field specific value", function () {
                    pages.new_deal.fillContractingPartiesField("bmi");
                });

                it(
                    "Wait for suggestions dropdown to appear", function () {
                        var suggestion = $(".tg-typeahead__suggestions-container");
                        browser.wait(ExpectedConditions.visibilityOf(suggestion));
                        expect(suggestion.getText()).not.toContain("No results");
                    }
                );

                it("Select specific suggestion", function () {
                        pages.new_deal.selectContractingPartyValue("(021)\n BMI");
                    }
                );

                it("Expect continue button to be enabled", function () {
                    expect(pages.new_deal.elems.continueButton.isEnabled);
                });

                it("Continue with next page", function () {
                    pages.new_deal.continueToNextPage();
                });

                it("Fill mandatory fields contract period", function () {
                    expect(pages.new_deal.elems.start_date.isDisplayed);
                    pages.new_deal.fillStartActualDate();
                    pages.new_deal.fillTargetEndMonths();
                });

                it("Add simple scope", function () {
                    pages.new_deal.addScopeForm();
                    //pages.new_deal.selectContractTypeScope("Administration");
                    //pages.new_deal.addTerritoryByTypingToScope();
                });
                it("Add new Royalty Rate Set",function()
                    {

                        pages.royaltyRates.clickNewRoyaltySetButton();
                    }

                );
                //it("Expand all Income Groups",function()
                //{
                //    pages.royaltyRates.expandAllIncomeGroups();
                //}
                //);
                //it("Fill the Contractual Rate field" , function()
                //{
                //
                //    pages.royaltyRates.fillContractualRate(80);
                //});

                it("Inspect Rate Set Form",function()
                {
                    //Add to be truthy to all
                  expect(pages.royaltyRates.elems.RRNameLabel.isPresent()).toBeTruthy();
                    expect(pages.royaltyRates.elems.incomeProvidesLabel.isPresent());
                    expect(pages.royaltyRates.elems.incomeProviderInput.isPresent());
                    expect(pages.royaltyRates.elems.incomeDateMethodLabel.isPresent());
                    expect(pages.royaltyRates.elems.dealSigningLabel.isPresent());
                    expect(pages.royaltyRates.elems.warnerChappelLabel.isPresent());
                    expect(pages.royaltyRates.elems.effectiveStartDateLabel.isPresent());
                    expect(pages.royaltyRates.elems.effectiveStartDateInput.isPresent());
                    expect(pages.royaltyRates.elems.contractualRateLabel.isPresent());
                    expect(pages.royaltyRates.elems.interCompanyLabel.isPresent());
                    expect(pages.royaltyRates.elems.interCompanyInput.isPresent());



                });
                it("Close Rate Set Form",function()
                {
                    pages.royaltyRates.closeRoyaltySet();


                  //  expect(browser.driver.findElements(by.xpath(".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[2]/div[1]/div[1]/label"))).toBeFalsy();

                    expect(pages.royaltyRates.elems.RRNameLabel.isPresent()).toBeFalsy();
                });

                it("Add new Royalty Rate Set",function()
                    {

                        pages.royaltyRates.clickNewRoyaltySetButton();
                    }

                );

                it("Delete Name from name input",function()
                    {
                       pages.royaltyRates.clearNameInput();
                    }
                );
                it("Error warning is shown for name input",function()
                {


                    var royaltyRateInput;

                    royaltyRateInput = browser.driver.findElement(by.xpath(".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[2]/div[1]/input"));

                  // royaltyRateInput.getCssValue('border-top-color').then(function (borderCssValue) {
                        expect(pages.royaltyRates.pagesreturnExpectValue()).toBe('rgba(223, 74, 72, 1)');
               //     });

                    royaltyRateInput.getCssValue('border-right-color').then(function (borderCssValue) {
                        expect(borderCssValue).toBe('rgba(223, 74, 72, 1)');
                    });
                    royaltyRateInput.getCssValue('border-bottom-color').then(function (borderCssValue) {
                        expect(borderCssValue).toBe('rgba(223, 74, 72, 1)');
                    });
                    royaltyRateInput.getCssValue('border-left-color').then(function (borderCssValue) {
                        expect(borderCssValue).toBe('rgba(223, 74, 72, 1)');
                    });

                    royaltyRateInput.getAttribute('placeholder').then(function(placeholderValue)
                    {
                        expect(placeholderValue).toBe('Type Name..');

                    });


                });

                it("Write Name in Rate Set Field ",function()
                {
                    var royaltyRateInput;

                    royaltyRateInput = browser.driver.findElement(by.xpath(".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[2]/div[1]/input"));

                    royaltyRateInput.sendKeys('First Rate Set');

                });
                it("Name is succesfully added to textbox",function()
                {

                    var royaltyRateInput;

                    royaltyRateInput = browser.driver.findElement(by.xpath(".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[2]/div[1]/input"));

                    royaltyRateInput.getAttribute('value').then(function(inputValue)
                    {
                        expect(inputValue).toBe('First Rate Set');

                    });

                });

                it("Remove Name , and type a really long name",function()
                {
                    var royaltyRateInput;

                    royaltyRateInput = browser.driver.findElement(by.xpath(".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[2]/div[1]/input"));

                    royaltyRateInput.clear();
                    royaltyRateInput.sendKeys('Really really really really really really really really long rate set name');
                    royaltyRateInput.getAttribute('value').then(function(inputValue)
                    {
                        expect(inputValue).toBe('Really really really really really really really really long rate set name');

                    });
                    royaltyRateInput.getCssValue('border-top-color').then(function (borderCssValue) {
                        expect(borderCssValue).toBe('rgba(51, 170, 237, 1)');
                    });
                    royaltyRateInput.getCssValue('border-right-color').then(function (borderCssValue) {
                        expect(borderCssValue).toBe('rgba(51, 170, 237, 1)');
                    });
                    royaltyRateInput.getCssValue('border-bottom-color').then(function (borderCssValue) {
                        expect(borderCssValue).toBe('rgba(51, 170, 237, 1)');
                    });
                    royaltyRateInput.getCssValue('border-left-color').then(function (borderCssValue) {
                        expect(borderCssValue).toBe('rgba(51, 170, 237, 1)');
                    });



                });
                it("Type in an income provider and select it from dropdown",function()
                {
                    var incomeProviderInput;

                    incomeProviderInput = browser.driver.findElement(by.xpath(".//*[@id='VIEW-CREATE-DEAL']/div[2]/form/div[1]/div[2]/div/div/div[3]/div[2]/div[2]/div/div[6]/div/div/div[2]/div/div[7]/div[2]/div/div[2]/div[2]/div[1]/div/div[1]/ul/li[1]/input"));

                    incomeProviderInput.sendKeys('TEST');
                    incomeProviderInput.click();

                    pages.royaltyRates.selectIncomeProvider();




                            });

                it("The Income Provider is succesfully added",function()
                {
                    var incomeProviderInput;

                    incomeProviderInput = browser.driver.findElement(by.css(".ux-multiselect-li.ux-multiselect-item.ng-scope.ng-binding"));


                        expect(incomeProviderInput.getText()).toBe('TEST\nx');




                });




                //it("Test Step",function()
                //{
                //    browser.pause();
                //
                //});
                //
                //



            });
        }
    };
}

module.exports = steps.new_deal;
